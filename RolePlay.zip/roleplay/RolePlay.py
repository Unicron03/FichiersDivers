from random import randint as rd

class Personnage:
    
    def __init__(self, nom, cat):
        """Fonction permettant l'initialisation de la class Personnage"""
        self.nom = nom
        self.pv = 20
        self.xp = 1
        self.cat = cat
        if self.cat == "Guerrier":
            self.inventaire = ["épée","potion"]
        elif self.cat == "Mage":
            self.inventaire = ["bâton","potion"]
        elif self.cat == "Voleur":
            self.inventaire = ["dague","potion"]
        elif self.cat == "Elfe":
            self.inventaire = ["arc","potion"]
            
    def restart():
        """Fonction permettant le début, ou non, d'une nouvelle partie"""
        print(" ")
        check = input("Voulez-vous commencer une nouvelle partie ? oui/non : ")
        if check == "oui":
            j1.pv = 20
            j2.pv = 20
        else:
            print(" ")
            print("A bientôt !")
            exit()
            
    def affiche_new_round():
        """Fonction permettant le début d'un nouveau tour"""
        if j1.pv > 0 and j2.pv > 0:
            check = input("Voulez-vous commencer une nouvelle attaque ? oui/non : ")
            if check == "oui":
                pass
            else:
                j1.affiche_winner()
        else:
            j1.affiche_winner()
        
    def choose_character():
        """Fonction permettant le choix du personnage"""
        global j1, j2
        j1 = Personnage(input("Quel est votre nom joueur 1 ? "), input("Quelle catégorie choisissez-vous entre Guerrier, Mage, Voleur et Elfe ? "))
        while j1.cat != "Guerrier" and j1.cat != "Mage" and j1.cat != "Voleur" and j1.cat != "Elfe":
            j1 = Personnage(input("Quel est votre nom joueur 1 ?"), input("Quelle catégorie choisissez-vous entre Guerrier, Mage, Voleur et Elfe ? "))
        j1.affiche_inventaire()
        
        print(" ")
        j2 = Personnage(input("Quel est votre nom joueur 2 ? "), input("Quelle catégorie choisissez-vous entre Guerrier, Mage, Voleur et Elfe ? "))
        while j2.cat != "Guerrier" and j2.cat != "Mage" and j2.cat != "Voleur" and j2.cat != "Elfe":
            j2 = Personnage(input("Quel est votre nom joueur 2 ? "), input("Quelle catégorie choisissez-vous entre Guerrier, Mage, Voleur et Elfe ? "))
        j2.affiche_inventaire()    
                
    def jet_attaque(self):
        """Jet d'attaque réalisé par l'attaquant"""
        if self.cat == "Guerrier" or self.cat == "Mage":
            atk = rd(1, 20) + self.xp * 10
        elif self.cat == "Voleur":
            atk = rd(1, 20) + self.xp * 3
        elif self.cat == "Elfe":
            atk = rd(1, 20) + self.xp * 8
        return atk
            
    def jet_defense(self):
        """Jet de défense réalisé par le défenseur"""
        if self.cat == "Guerrier":
            defense = rd(1, 20) + self.xp * 8
        elif self.cat == "Mage":
            defense = rd(1, 20) + self.xp * 7
        elif self.cat == "Voleur":
            defense = rd(1, 20) + self.xp * 9
        elif self.cat == "Elfe":
            defense = rd(1, 20) + self.xp * 10
        return defense
    
    def change_pv(self, nb_pv):
        """Fonction permettant la diminution des PV du perdant à chaque tour"""
        self.pv = self.pv - nb_pv
        
    def change_xp(self, nb_xp):
        """Fonction permettant l'incrémentation d'xp pour le gagnant après une partie"""
        self.xp = self.xp + nb_xp

    def affiche_car(self, check):
        """Fonction permettant l'affichage des caractéristiques du joueur après un tour"""
        if check == "win":
            if self.cat == "Elfe":
                print("Youpi ! L'Elfe {} de niveau {} remporte ce tour ! Il lui reste {} PV.".format(self.nom, self.xp, self.pv))
            else:
                print("Youpi ! Le {} {} de niveau {} remporte ce tour ! Il lui reste {} PV.".format(self.cat, self.nom, self.xp, self.pv))
        else:
            if self.cat == "Elfe":
                print("Aïe ! L'Elfe {} de niveau {} viens de subir une terrible attaque ! Il lui reste {} PV !".format(self.nom, self.xp, self.pv))
            else:
                print("Aïe ! Le {} {} de niveau {} viens de subir une terrible attaque ! Il lui reste {} PV !".format(self.cat, self.nom, self.xp, self.pv))

    def affiche_inventaire(self):
        """Fonction permettant l'affichage de l'inventaire"""
        print(" ")
        if self.cat == "Elfe":
            print("Bonjour {} ! Voici votre inventaire en tant qu' {} : ".format(self.nom, self.cat))
        else:
            print("Bonjour {} ! Voici votre inventaire en tant que {} : ".format(self.nom, self.cat))
        
        for objet in self.inventaire:
            print("- {}".format(objet))
        print(" ")
            
    def affiche_winner(self):
        """Fonction permettant l'affichage du gagnant"""
        print(" ")
        if j1.pv > j2.pv:
            if self.cat == "Elfe":
                print("L' Elfe {} à écraser {} le {} !".format(j1.nom, j2.nom, j2.cat))
                j1.change_xp(1)
            else:
                print("Le {} {} à écraser {} le {} !".format(j1.cat, j1.nom, j2.nom, j2.cat))
                j1.change_xp(1)
        elif j1.pv == j2.pv:
            print("Une bataille acharnée qui se conclut par une égalité !")
        else:
            if self.cat == "Elfe":
                print("L'Elfe {} s'est fait écraser par {} le {} !".format(j1.nom, j2.nom, j2.cat))
                j2.change_xp(1)
            else:
                print("Le {} {} s'est fait écraser par {} le {} !".format(j1.cat, j1.nom, j2.nom, j2.cat))
                j2.change_xp(1)
        print("Score : {} pour {} à {} pour {}.".format(j1.pv, j1.nom, j2.pv, j2.nom))
        Personnage.restart()


    
class Game:
    
    def __init__(self):
        """Fonction permettant l'initialisation de la class Game"""
        self.tour = 0
        
    def run(self):
        """Fonction executant la boucle principale du jeu"""
        self.tour = self.tour + 1
        if self.tour%2 == 1:
            if j1.jet_attaque() > j2.jet_defense():
                j2.change_pv(rd(1, 8))
                print(" ")
                j1.affiche_car("win")
                j2.affiche_car("defeat")
                print(" ")
            else:
                j1.change_pv(rd(1, 4))
                print(" ")
                j1.affiche_car("defeat")
                j2.affiche_car("win")
                print(" ")
        else:
            if j2.jet_attaque() > j1.jet_defense():
                j1.change_pv(rd(1, 8))
                print(" ")
                j2.affiche_car("win")
                j1.affiche_car("defeat")
                print(" ")
            else:
                j2.change_pv(rd(1, 4))
                print(" ")
                j1.affiche_car("win")
                j2.affiche_car("defeat")
                print(" ")
        print(self.tour)
        Personnage.affiche_new_round()
        
        
Personnage.choose_character()
while j1.pv > 0 and j2.pv > 0:
    Game().run()