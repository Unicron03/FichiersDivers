from random import randint as rd
import sqlite3

class Personnage:
    def __init__(self, nom, cat):
        """Fonction permettant l'initialisation de la class Personnage"""
        self.nom = nom
        self.cat = cat
        self.spe = [(self.nom, "20", "1", self.cat)]
        cur.executemany("INSERT INTO personnage VALUES (?, ?, ?, ?)", self.spe)
        con.commit()
        
    def restart():
        """Fonction permettant le début, ou non, d'une nouvelle partie"""
        print(" ")
        check = input("Voulez-vous commencer une nouvelle partie ? oui/non : ")
        if check == "oui":
            Utility.upd_pv('20', Utility.lect_nom(0))
            Utility.upd_pv('20', Utility.lect_nom(1))
            print(" ")
        else:
            print(" ")
            print("A bientôt !")
            exit()
            
    def choose_caracter():
        """Fonction permettant le choix du personnage"""
        Personnage(input("Quel est votre nom joueur 1 ? "), input("Quelle catégorie choisissez-vous entre Guerrier, Mage, Voleur et Elfe ? "))
        while Utility.lect_cat([Utility.lect_nom(0)]) != "Guerrier" and Utility.lect_cat([Utility.lect_nom(0)]) != "Mage" and Utility.lect_cat([Utility.lect_nom(0)]) != "Voleur" and Utility.lect_cat([Utility.lect_nom(0)]) != "Elfe":
            cur.execute("delete from personnage where nom=(?)", [Utility.lect_nom(0)])
            Personnage(input("Quel est votre nom joueur 1 ? "), input("Quelle catégorie choisissez-vous entre Guerrier, Mage, Voleur et Elfe ? "))
        Personnage.affiche_inventaire(Utility.lect_nom(0))  
        print(" ")
        Personnage(input("Quel est votre nom joueur 2 ? "), input("Quelle catégorie choisissez-vous entre Guerrier, Mage, Voleur et Elfe ? "))
        while Utility.lect_cat([Utility.lect_nom(1)]) != "Guerrier" and Utility.lect_cat([Utility.lect_nom(1)]) != "Mage" and Utility.lect_cat([Utility.lect_nom(1)]) != "Voleur" and Utility.lect_cat([Utility.lect_nom(1)]) != "Elfe":
            cur.execute("delete from personnage where nom=(?)", [Utility.lect_nom(1)])
            Personnage(input("Quel est votre nom joueur 2 ? "), input("Quelle catégorie choisissez-vous entre Guerrier, Mage, Voleur et Elfe ? "))
        Personnage.affiche_inventaire(Utility.lect_nom(1))
            
    def jet_attaque(nom):
        """Jet d'attaque réalisé par l'attaquant"""
        if Utility.lect_cat([nom]) == "Guerrier" or Utility.lect_cat([nom]) == "Mage":
            atk = rd(1, 20) + Utility.lect_xp([(nom)]) * 10
        elif Utility.lect_cat([nom]) == "Voleur":
            atk = rd(1, 20) + Utility.lect_xp([(nom)]) * 3
        elif Utility.lect_cat([nom]) == "Elfe":
            atk = rd(1, 20) + Utility.lect_xp([(nom)]) * 8
        return atk
            
    def jet_defense(nom):
        """Jet de défense réalisé par le défenseur"""
        if Utility.lect_cat([nom]) == "Guerrier":
            defense = rd(1, 20) + Utility.lect_xp([(nom)]) * 8
        elif Utility.lect_cat([nom]) == "Mage":
            defense = rd(1, 20) + Utility.lect_xp([(nom)]) * 7
        elif Utility.lect_cat([nom]) == "Voleur":
            defense = rd(1, 20) + Utility.lect_xp([(nom)]) * 9
        elif Utility.lect_cat([nom]) == "Elfe":
            defense = rd(1, 20) + Utility.lect_xp([(nom)]) * 10
        return defense

    def affiche_car(check, nom):
        """Fonction permettant l'affichage des caractéristiques du joueur après un tour"""
        if check == "win":
            if Utility.lect_cat([nom]) == "Elfe":
                print("Youpi ! L'Elfe {} de niveau {} remporte ce tour ! Il lui reste {} PV.".format(nom, Utility.lect_xp([nom]), Utility.lect_pv([nom])))
            else:
                print("Youpi ! Le {} {} de niveau {} remporte ce tour ! Il lui reste {} PV.".format(Utility.lect_cat([nom]), nom, Utility.lect_xp([nom]), Utility.lect_pv([nom])))
        else:
            if Utility.lect_cat([nom]) == "Elfe":
                print("Aïe ! L'Elfe {} de niveau {} viens de subir une terrible attaque ! Il lui reste {} PV !".format(nom, Utility.lect_xp([nom]), Utility.lect_pv([nom])))
            else:
                print("Aïe ! Le {} {} de niveau {} viens de subir une terrible attaque ! Il lui reste {} PV !".format(Utility.lect_cat([nom]), nom, Utility.lect_xp([nom]), Utility.lect_pv([nom])))

    def affiche_inventaire(nom):
        """Fonction permettant l'affichage de l'inventaire"""
        print(" ")
        if Utility.lect_cat([(nom)]) == "Elfe":
            print("Bonjour {} ! Voici votre inventaire en tant qu'Elfe : ".format(nom))
        else:
            print("Bonjour {} ! Voici votre inventaire en tant que {} : ".format(nom, Utility.lect_cat([(nom)])))
        
        inv = Utility.lect_inv(Utility.lect_cat([(nom)]))
        for objet in inv:
            print("- {}".format(objet))
            
    def affiche_new_round():
        """Fonction permettant le début d'un nouveau tour"""
        print(" ")
        if Utility.lect_pv([(Utility.lect_nom(0))]) > 0 and Utility.lect_pv([(Utility.lect_nom(1))]) > 0:
            check = input("Voulez-vous commencer une nouvelle attaque ? oui/non : ")
            if check == "oui":
                pass
            else:
                Personnage.affiche_winner()
        else:
            Personnage.affiche_winner()
            
    def affiche_winner():
        """Fonction permettant l'affichage du gagnant"""
        print(" ")
        if Utility.lect_pv([(Utility.lect_nom(0))]) > Utility.lect_pv([(Utility.lect_nom(1))]):
            if Utility.lect_cat([Utility.lect_nom(0)]) == "Elfe":
                print("L' Elfe {} à écraser {} le {} !".format(Utility.lect_nom(0), Utility.lect_nom(1), Utility.lect_cat([Utility.lect_nom(1)])))
                Utility.upd_xp(str(Utility.lect_xp([Utility.lect_nom(0)])+1), Utility.lect_nom(0))
            else:
                print("Le {} {} à écraser {} le {} !".format(Utility.lect_cat([Utility.lect_nom(0)]), Utility.lect_nom(0), Utility.lect_nom(1), Utility.lect_cat([Utility.lect_nom(1)])))
                Utility.upd_xp(str(Utility.lect_xp([Utility.lect_nom(0)])+1), Utility.lect_nom(0))
        elif Utility.lect_pv([(Utility.lect_nom(0))]) == Utility.lect_pv([(Utility.lect_nom(1))]):
            print("Une bataille acharnée qui se conclut par une égalité !")
        else:
            if Utility.lect_cat([Utility.lect_nom(1)]) == "Elfe":
                print("L'Elfe {} s'est fait écraser par {} le {} !".format(Utility.lect_nom(0), Utility.lect_nom(1), Utility.lect_cat([Utility.lect_nom(1)])))
                Utility.upd_xp(str(Utility.lect_xp([Utility.lect_nom(1)])+1), Utility.lect_nom(1))
            else:
                print("Le {} {} s'est fait écraser par {} le {} !".format(Utility.lect_cat([Utility.lect_nom(0)]), Utility.lect_nom(0), Utility.lect_nom(1), Utility.lect_cat([Utility.lect_nom(1)])))
                Utility.upd_xp(str(Utility.lect_xp([Utility.lect_nom(1)])+1), Utility.lect_nom(1))
        print("Score : {} pour {} à {} pour {}.".format(Utility.lect_pv([Utility.lect_nom(0)]), Utility.lect_nom(0), Utility.lect_pv([Utility.lect_nom(1)]), Utility.lect_nom(1)))
        Personnage.restart()



class Utility:
    def upd_pv(val, nom):
        """Fonction permettant l'update des pv du joueur"""
        #forme upd_pv('val', 'nom')
        cur.execute("update personnage set pv=(?) where nom=(?)", (val, nom))
        con.commit()

    def upd_xp(val, nom):
        """Fonction permettant l'update de l'xp du joueur"""
        #forme upd_xp('val', 'nom')
        cur.execute("update personnage set xp=(?) where nom=(?)", (val, nom))
        con.commit()

    def lect_pv(nom):
        """Fonction permettant la lacture des pv du joueur"""
        #forme lect_pv(['nom'])
        cur.execute("select pv from personnage where nom=(?)", nom)
        pv = cur.fetchall()[0][0]
        return pv

    def lect_xp(nom):
        """Fonction permettant la lecture de l'xp du joueur"""
        #forme lect_xp(['nom'])
        cur.execute("select xp from personnage where nom=(?)", nom)
        xp = cur.fetchall()[0][0]
        return xp

    def lect_nom(rang):
        """Fonction permettant la lecture du nom du joueur"""
        # forme lect_nom(rang)
        cur.execute('select nom from personnage')
        nom = cur.fetchall()[rang][0]
        return nom

    def lect_cat(nom):
        """Fonction permettant la lecture de la catégorie du joueur"""
        #forme lect_cat(['nom'])
        cur.execute("select cat from personnage where nom=(?)", nom)
        cat = cur.fetchall()[0][0]
        return cat
    
    def lect_inv(cat):
        # forme lect_inv(lect_cat([(nom)]))
        if cat == "Guerrier":
            inventaire = ["épée","potion"]
        elif cat == "Mage":
            inventaire = ["bâton","potion"]
        elif cat == "Voleur":
            inventaire = ["dague","potion"]
        elif cat == "Elfe":
            inventaire = ["arc","potion"]
        return inventaire
    
    

class Main:
    def initialisation():
        """Fonction permettant l'initialisation du jeu"""
        global tour
        cur.execute('''CREATE TABLE if not exists personnage
                    (nom TEXT, pv FLOAT, xp FLOAT, cat TEXT)''')
        cur.execute("delete from personnage")
        Personnage.choose_caracter()
        Personnage.restart()
        tour = 1
                     
    def run():
        """Fonction permettant le déroulement de la partie"""
        if tour%2 == 1:
            print("paire")
            if Personnage.jet_attaque(Utility.lect_nom(0)) > Personnage.jet_defense(Utility.lect_nom(1)):
                Utility.upd_pv(str(Utility.lect_pv([Utility.lect_nom(1)])-rd(1, 8)), Utility.lect_nom(1))
                Personnage.affiche_car("win", Utility.lect_nom(0))
                Personnage.affiche_car("defeat", Utility.lect_nom(1))
            else:
                Utility.upd_pv(str(Utility.lect_pv([Utility.lect_nom(0)])-rd(1, 4)), Utility.lect_nom(0))
                Personnage.affiche_car("defeat", Utility.lect_nom(0))
                Personnage.affiche_car("win", Utility.lect_nom(1))
        else:
            print("impaire")
            if Personnage.jet_attaque(Utility.lect_nom(0)) > Personnage.jet_defense(Utility.lect_nom(0)):
                Utility.upd_pv(str(Utility.lect_pv([Utility.lect_nom(0)])-rd(1, 8)), Utility.lect_nom(0))
                Personnage.affiche_car("defeat", Utility.lect_nom(0))
                Personnage.affiche_car("win", Utility.lect_nom(1))
            else:
                Utility.upd_pv(str(Utility.lect_pv([Utility.lect_nom(1)])-rd(1, 4)), Utility.lect_nom(1))
                Personnage.affiche_car("win", Utility.lect_nom(0))
                Personnage.affiche_car("defeat", Utility.lect_nom(1))
        Personnage.affiche_new_round()



con = sqlite3.connect("personnage.db")
cur = con.cursor()
Main.initialisation()
while Utility.lect_pv([(Utility.lect_nom(0))]) > 0 and Utility.lect_pv([(Utility.lect_nom(1))]) > 0:
    Main.run()